/*
	Name:		<full name>
	Roll No:	<roll number>
	Course:		CS2130 DSA Lab 
	Semester:	2024 Jan-Apr
	Lab:		Week 8
	Tasks:		1 to 6
	
	Aim: 		Implement a Binary Search Tree (BST)
	Definition:	A BST is a binary tree such that the value (key) at every node is
				more than that of the largest key in it's left subtree (if it exists) and
				less than that of the smallest key it's right subtree (if it exists).
				Check the function is_bst()
	Assume:		All keys to be stored are integers.
				No two keys are the same.
	Inst:		Do not change any function interface
*/

#include <stdio.h>
#include <stdlib.h>	// Needed for malloc, free etc
#include <time.h>	// To seed random number generator
#include <limits.h>	// For INT_MIN
#include "quick-sort.h"

/* 	The stucture to store the key and pointers for a single node.
	The same structure also can be treated as the definition of a binary tree
	-	A null pointer is a binary tree (empty tree)
	-	A node with a key and two pointers to two binary trees is a binary tree.
*/
typedef struct Tree {
    int key;
	int count; //count for duplicates.
    struct Tree* left;
    struct Tree* right;
} Tree;		

Tree* create_node(int key, Tree* left, Tree* right) {
/*
	Inputs:
		1. 	Key for the new node to be inserted
		2.	A pointer to be set as the left child
		3.	A pointer to be set as the right child
	Actions:
		1.	Memory required for a new node is allotted.
		2.	The data and the child pointers of the new node are set from the inputs
	Error Response:
		1.	Prints "Error: Memory allocation for new node failed." to stderr if
			malloc fails.	
		2.	Returns NULL if the new node cannot be created
*/
	Tree* new = (Tree *) malloc(sizeof(Tree));
	if(new == NULL) {
		fprintf(stderr, "Error: Memory allocation for new node failed\n");
		return NULL;
		}
	new->key 	= key;
	new->left 	= left;
	new->right 	= right;
    new->count = 1;
	return new;
}

void free_tree(Tree* t) {
	if (t == NULL)
		return;
	else {
		free_tree(t->left);
		free_tree(t->right);
		free(t);
		return;
	}
}

/* Helper function to return the height of a binary tree */
int height(Tree *tree) {
	if (tree == NULL)
		return 0;
	else {
		int hl 	= height(tree->left);
		int hr 	= height(tree->right);
		int hmax = (hl > hr) ? hl : hr;
		return hmax + 1;
	}
}

/*	Helper function to print one level of a binary tree
*/
void print_level(Tree* t, int t_level, int p_level, int height) {
/*
	Inputs:
		1.	Top level node t
		2.	Height of the top level node (t) in the whole binary tree
		3.	Level of the binary tree to be printed
		4.	Height of the whole binary tree
*/
	if(t_level > p_level) {
		fprintf(stderr, "Error in print_level\n");
		return;
		}
	if(t_level < p_level) {
		if (t != NULL)
			print_level(t->left, t_level+1, p_level, height);
		else
			print_level(NULL, t_level+1, p_level, height);

		if (t != NULL)
			print_level(t->right, t_level+1, p_level, height);
		else
			print_level(NULL, t_level+1, p_level, height);
		return;
	}

	// t_level == p_level
	int padding = 1;	// for alignment
	for (int i = p_level; i < height-1; i++)
		padding = padding * 2 + 1;

	// To prefix some space and a line 
	for (int i = 0; i < (padding+1)/2; i++)
		printf("  ");
	for (int i = (padding+1)/2; i < padding; i++)
		printf("__");

	if (t != NULL)
		printf("%2d", t->key);	
	else
		printf("()");	

	// To suffix a line and some space
	for (int i = (padding+1)/2; i < padding; i++)
		printf("__");
	for (int i = 0; i < (padding+1)/2; i++)
		printf("  ");

	printf("  ");
	return;
}

/*	Helper function to print the binary tree in a tree-like way.
*/
void print_tree(Tree* t) {
	int h = height(t);
	for(int l = 0; l < h; l++) {
		print_level(t, 0, l, h);
		printf("\n");
		}
	return;
}

int find_min(Tree* tree){
/*
	Input:  A BST 
	Output: Minimum key in the BST if it is non-empty.
			INT_MAX if the BST is empty.
*/
	// Task 2a Solution
	if (tree == NULL)
		return INT_MAX;

	while(tree->left != NULL)
		tree = tree->left;

	return tree->key;
}

int find_max(Tree* tree){
/*
	Input:  A BST 
	Output: Maximum key in the BST if it is non-empty.
			INT_MIN if the BST is empty.
*/
	// Task 2b Solution
	if (tree == NULL)
		return INT_MIN;

	while(tree->right != NULL)
		tree = tree->right;

	return tree->key;
}

/* Task 1. Insert
	Implement a function to create a new node with the given key and add it to
	a BST such that the resulting binary tree also satisfies the BST property.
	No change is to be made if the given key is already in the BST.
*/
Tree* insert(int key, Tree* tree) {
/*
	Inputs:
		1. 	Key for the new node to be inserted
		2.	A BST 
	Actions:
		1.	If the key is present in the tree, do nothing.
		2.	Else create a node with the received key and insert it at the correct
			position in tree.
		2.	The pointer to the root of the tree is returned (this will change
			only if the insert happens at the root).
	Error Response:
		1.	Prints "Error: Insertion failed." to stderr
		2.	Returns NULL if the actions fail
*/

	// Task 1 Solution
	Tree *new = create_node(key,NULL,tree);
	if (tree == NULL){
		return new;
	}
	else if (key < tree->key)
	{
		tree->left = insert(key,tree->left);
	}
	else if (key > tree->key)
	{
		tree->right = insert(key,tree->right);
	}
	else{
		tree->count++;
		return tree;
	}

	return tree; // You may want to edit this
}

/* Task 2: Find Predecessor.  Goal of this function to find the predecessor value present in a 
                              given BST for a given input value. The predecessor for a given input
                              value is the maximum among all the keys which are (strictly) less 
                              than the given value if it exists, otherwise it is defined as -1.
                              
                              Example:   Let the BST contain the values 10, 20, 30, 40, 50, 60. 
                                Then the following list shows the predecessor values corresponding to each input.
                                Input (val)          Predecessor
                               ------          -------------
                                5                  -1
                                10                 -1
                                30                 20 
                                35                 30 
                                100                60
*/


int find_predecessor (int val, Tree* tree){
    
/*       Inputs:
		1. 	val: An integer value
		2.	tree: A BST 
	Actions:
		1.	.
		2.	Else create a node with the received key and insert it at the correct
			position in tree.
		2.	The pointer to the root of the tree is returned (this will change
			only if the insert happens at the root).
	
*/

  /* Task 2 Solutions */
	int ans = -1;
	if (val == tree->key){
		return find_max(tree->left);
	}
	Tree *t = tree;
	while (t!=NULL)
	{
		if (val < t->key){
			t = t->left;
		}
		else if (val > t->key)
		{
			ans = t->key;
			t = t->right;
		}
		else{
			return ans;
		}
	}
	return ans;
}


/* Helper function to check if a binary tree is a BST
*/
int is_bst(Tree* t) {
	if (t == NULL)
		return 1;
	if (
		is_bst(t->left) 
		&& is_bst(t->right)
		&& (find_max(t->left) < t->key) 
		&& (find_min(t->right) > t->key)
	)
		return 1;
	return 0;
}

/* Task 3. Find Closest
	Implement a function to search for a key in the given BST which is closest
	to a given value, i.e., |val - key| is smallest among all key in the BST. 
	In case of a tie return the smaller key.
	
	Example:   Let the BST contain the values 10, 20, 30, 40, 50, 60. 
                                Then the following list shows the closest values corresponding to each input.
                                Input (val)       Closest
                               ------          -------------
                                5                  10
                                10                 10
                                23                 20 
                                37                 40 
                                45                 40
                                100                60
*/
int find_closest(int val, Tree* tree) {
/*
	Inputs: A value (val) and a BST (tree) 
	Actions:
		1.	Return the key in the BST that is closest to the given input value
			
		2.	-1 if the tree is NULL
*/
	// Task 3 Solution
    int ans = INT_MAX;
	Tree *t = tree;
	while (t!=NULL)
	{
		if (abs(val-t->key) < abs(val- ans)){
			ans = t->key;
		}
		if (val < t->key){
			t = t->left;
		}
		else if (val > t->key){
			t = t->right;
		}
		else{
			return ans;
		}
	}
	return ans; // You may want to edit this
}





/* Task 4. Delete Closest: Delete the closest element in the BST of the given value, where the closest
element is as defined in the previous task.
*/
Tree* delete_closest(int val, Tree* tree) {
/*
	Inputs: A val and a BST
	Actions:
		1.	Delete the element in the BST that is closest to the given value.
		2.	Return NULL if the BST is empty (NULL).
*/
	// Task 5 Solution
	if (tree == NULL){
		return NULL;
	}
  
    int near = find_closest(val,tree);
	Tree *t = tree;
	if (near < t->key){
		t->left = delete_closest(near,t->left);
	}
	else if(near > t->key){
		t->right = delete_closest(near,t->right);
	}
	else{
		if (t->left == NULL){
			return t->right;
		}
		else if(t->right == NULL) {
			return t->left;
		}
		else{
			t->key = find_predecessor(t->key,t);
			t->left = delete_closest(t->key,t->left);
		}
	}
	return tree;
}


/* Task 5. Tree Sort: Sort an input array using a BST and return the number of distinct items in
the array */

/************ Note that the array may contain duplicate entries which should be taken into account
and need to be preserved in the final sorted array. So, you may have to change the node structure
of the BST ****************/

int inde = 0;
int length = 0;
void inorder(int a[],Tree* t){
	 if (t == NULL){
		return;
	 }
	 inorder(a,t->left);
	 while (t->count--)
	 {
		a[inde++]=t->key;
	 }
	 inorder(a,t->right);
	 length++;
}

int sort_tree(int a[], int size) {
/*
	Inputs: An array a and its size
	Action: Sorts the input array a using tree 
	Returns: The input array should be sorted and the return value
	is the number of distinct items in the array
*/
	// Task 5 Solution
	Tree* t =NULL;
	inde = 0;
	length=0;
	for (int i = 0; i < size; i++)
	{
		t = insert(a[i],t);	
	}
	inorder(a,t);
	
	return length;
}


/* 	All the testing for the tasks are included in the main. 
	Uncomment them one by one after you code the corresponding tasks in order.
*/
int main() {
	srand(time(0));		// Seed the random number generator

	Tree *t = NULL;
	int key, min, max;
	//Test Task 1. Insert
	printf("\nTesting Task 1. Insert\n");
	printf("========================\n");
	
	printf("Inserting 16 numbers in the best possible order\n");
	int nice_order[] = {8, 4, 12, 2, 6, 10, 14, 1, 3, 5, 7, 9, 11, 13, 15};
	
	for (int i = 0; i < 15; i++) {
		key = nice_order[i];
		printf("Inserting %d\n", key);
		t = insert(key, t);
		print_tree(t);
		}
		
		print_tree(t);
		if(is_bst(t))
		printf("Satisfies BST property\n");
		free_tree(t);
		
		// Test a tree created by inserting random keys
		printf("\n\nTree emptied. Inserting 8 new random numbers.\n");
		t = NULL;
		
		for (int i = 0; i < 10; i++) {
			key = 10 + rand() % 90;
			printf("Inserting %d\n", key);
			t = insert(key, t);
			print_tree(t);
			}
			
			print_tree(t);
			if(is_bst(t))
			printf("Satisfies BST property\n");
			

	// Test Task 2. Find Min and Max
	printf("\nTesting Task 2. Find Predecessor\n");
	printf("======================================\n");

	min = find_min(t);
	max = find_max(t);
	printf("Predecessor of 0 is %d\n", find_predecessor(0, t));
	printf("Predecessor of %d is %d\n", min, find_predecessor(min, t));
	printf("Predecessor of %d is %d\n",(min+max)/2, find_predecessor((min+max)/2, t));
	printf("Predecessor of %d is %d\n",t->key, find_predecessor(t->key, t));
	printf("Predecessor of %d is %d\n",max+10, find_predecessor(max+10, t));
	

	// Test Task 3. Find Closest
	printf("\nTesting Task 3. Find Closest\n");
	printf("========================\n");
	printf("Closest of 0 is %d\n", find_closest(0, t));
	printf("Closest of %d is %d\n", min, find_closest(min, t));
	printf("Closest of %d is %d\n",(min+max)/2, find_closest((min+max)/2, t));
	printf("Closest of %d is %d\n",(min+max)/2+23, find_closest((min+max)/2+23, t));
	printf("Closest of %d is %d\n",(min+max)/2+17, find_closest((min+max)/2+17, t));
	printf("Closest of %d is %d\n",t->key, find_closest(t->key, t));
	printf("Closest of %d is %d\n",max+10, find_closest(max+10, t));
	
	printf("\n");
	
		
	// Test Task 4. Delete Closest
	printf("\nTesting Task 3. Delete Closest\n");
	printf("========================\n");
	printf(" Deleting closest of 0\n");
	t = delete_closest(0, t);
		print_tree(t);
		if(is_bst(t))
		printf("Satisfies BST property\n");
		
	printf("Deleting closest of %d\n", t->key);
	t = delete_closest(t->key, t);
		print_tree(t);
		if(is_bst(t))
		printf("Satisfies BST property\n");	
		
	printf("Deleting closest of %d\n", min);
	t = delete_closest(min, t);
		print_tree(t);
		if(is_bst(t))
		printf("Satisfies BST property\n");
		
	printf("Deleting closest of %d\n", (min+max)/2);
	t = delete_closest((min+max)/2, t);
		print_tree(t);
		if(is_bst(t))
		printf("Satisfies BST property\n");
		
	printf("Deleting closest of %d\n", (min+max)/2+23);
	t = delete_closest((min+max)/2+23, t);
		print_tree(t);
		if(is_bst(t))
		printf("Satisfies BST property\n");
		
	printf("Deleting closest of %d\n", (min+max)/2+17);
	t = delete_closest((min+max)/2+17, t);
		print_tree(t);
		if(is_bst(t))
		printf("Satisfies BST property\n");	
	
	printf("Deleting closest of %d\n", max+10);
	t = delete_closest(max+10, t);
		print_tree(t);
		if(is_bst(t))
		printf("Satisfies BST property\n");	
	
	printf("\n");
	

	
	free_tree(t);

	// Task 5: Tree Sort
	int size = 37, j, k=2, l=0, i;
	int array[37];
	for (i =0; i < 37; i++){
	  j = 6*i % size;
	  array[j] = k;
	  l++;
	  if(l == k){
	      l = 0;
	      k= k+1;
	  }
	
	}
	sort_tree(array, size);
	if (is_sorted(array, size)) {
	    printf("Tree Sort: Passed\n\n ");
	    for (i = 0; i< 37; i++){
	      printf("%d\n", array[i]);
	    }
	 }   
	else {
		printf("Tree Sort: \t Failed\n");
	}
	
	
	// Timing Tree Sort
	
	
	clock_t start, end;
	size = 1000000;
	printf("\nTiming different sorting algorithms on an array of size %d.\n", size);
	printf("=============================================================\n");

	// Populates four arrays with the same unsorted data 
	int *data1 = (int*) malloc(size * sizeof(int));
	int *data2 = (int*) malloc(size * sizeof(int));
	if (data1 == NULL || data2 == NULL) {
		fprintf(stderr, "Memory Allocation Failed\n");
		exit(1);
	}
	else {
		printf("Memory for an array of size %d allotted successfully.\n", size);
	}
	for (int i = 0; i < size; i++) {
		data1[i] = rand();
		data2[i] = data1[i];
	}

	// Tree Sort data1
	start = clock();
	int size1 = sort_tree(data1, size);
	end = clock();

	if (is_sorted(data1, size1)) 
		printf("Tree Sort: \t %ld clock cycles, %d unique elements\n", end-start, size1);
	else {
		printf("Tree Sort: \t Failed\n");
		for(int i = 0; i < 100; i++)
			printf("%d\n", data1[i]);
	}

	// Quick Sort data2
	start = clock();
	sort_quick(data2, size);
	end = clock();

	if (is_sorted(data2, size)) 
		printf("Quick Sort: \t %ld clock cycles\n", end-start);
	else
		printf("Quick Sort: \t Failed\n");

	return 0;
}


