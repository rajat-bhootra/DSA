#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define MAXV 100 // Maximum number of vertices

// Colors for DFS
#define WHITE 0
#define GRAY  1
#define BLACK 2

typedef struct edgenode {
    int y;
    struct edgenode *next;
} edgenode;

typedef struct {
    edgenode *edges[MAXV+1];
    int degree[MAXV+1];
    int nvertices;
    int nedges;
    bool directed;
} graph;

typedef struct {
    int color;
    int d;
    int f;
    int parent;
} dfs_vertex;

int time = 0;
dfs_vertex vertices[MAXV+1];

void initialize_graph(graph *g, bool directed) {
    g->nvertices = 0;
    g->nedges = 0;
    g->directed = directed;
    for (int i = 1; i <= MAXV; i++) {
        g->edges[i] = NULL;
        g->degree[i] = 0;
    }
}

void insert_edge(graph *g, int x, int y, bool directed) {
    edgenode *p = malloc(sizeof(edgenode));
    p->y = y;
    p->next = g->edges[x];
    g->edges[x] = p;
    g->degree[x]++;
    g->nedges++;

    if (!directed) {
        edgenode *q = malloc(sizeof(edgenode));
        q->y = x;
        q->next = g->edges[y];
        g->edges[y] = q;
        g->degree[y]++;
    }
}

void print_graph(graph *g) {
    printf("Graph has %d vertices and %d edges\n", g->nvertices, g->nedges);
    printf("Graph is %s\n", g->directed ? "directed" : "undirected");
    for (int i = 1; i <= g->nvertices; i++) {
        printf("%d: ", i);
        edgenode *p = g->edges[i];
        while (p != NULL) {
            printf(" %d", p->y);
            p = p->next;
        }
        printf("\n");
    }
}

/*
Approach for dfs_visit:
1. Mark the current node as discovered (GRAY) and record discovery time
2. For each adjacent node:
   - If WHITE (unvisited), recursively visit it and set parent
3. Mark the current node as finished (BLACK) and record finish time

*/
void dfs_visit(graph *g, int u) {
    // Task 1 solution here
    edgenode * temp = g->edges[u];
    time += 1;
    vertices[u].color = GRAY;
    vertices[u].d = time;
    while (temp != NULL)
    {
        if(vertices[temp->y].color == WHITE){
            vertices[temp->y].parent = u;
            dfs_visit(g,temp->y);
        }
        temp = temp->next;
    }
    vertices[u].color = BLACK;
    time++;
    vertices[u].f = time;
    
}

/*
Approach for dfs_visit_with_classification:
1. Same as basic dfs_visit but with edge classification:
   - Tree edges: when visiting WHITE nodes
   - Back edges: when encountering GRAY nodes (cycle detection)
   - Forward/Cross edges: in directed graphs based on timestamps
2. Print edge types during traversal

Possible prints:
- printf("Edge (%d, %d): Tree Edge\n", u, v);
- printf("Edge (%d, %d): Back Edge\n", u, v);
- printf("Edge (%d, %d): Forward Edge\n", u, v);
- printf("Edge (%d, %d): Cross Edge\n", u, v);
*/
void dfs_visit_with_classification(graph *g, int u) {
    // Task 2 solution here
    if(g->directed){
        edgenode * v = g->edges[u];
        time ++;
        vertices[u].color = GRAY;
        vertices[u].d = time;
        while (v != NULL)
        {
            if(vertices[v->y].color == WHITE){
                vertices[v->y].parent = u;
                printf("Edge (%d, %d): Tree Edge\n", u, v->y);
                dfs_visit_with_classification(g,v->y);
            }
            else if (vertices[v->y].color == GRAY)
            {
                printf("Edge (%d, %d): Back Edge\n", u, v->y);
            }
            else if (vertices[v->y].color == BLACK){
                  if (vertices[u].d <= vertices[v->y].d){
                    printf("Edge (%d, %d): Forward Edge\n", u, v->y);
                  }
                  else {
                    printf("Edge (%d, %d): Cross Edge\n", u, v->y);
                  }
            }
            v = v->next;
        }
        time++;
        vertices[u].color = BLACK;
        vertices[u].f = time;
    }
    else{
        edgenode * v = g->edges[u];
        time ++;
        vertices[u].color = GRAY;
        vertices[u].d = time;
        while (v != NULL)
        {
            if(vertices[v->y].color == WHITE){
                
                vertices[v->y].parent = u;
                printf("Edge (%d, %d): Tree Edge\n", u, v->y);
                dfs_visit_with_classification(g,v->y);
            }
            else if (vertices[v->y].color == GRAY && vertices[u].parent != v->y)
            {
                printf("Edge (%d, %d): Back Edge\n", u, v->y);
            }
            v = v->next;
        }
        time++;
        vertices[u].color = BLACK;
        vertices[u].f = time;
        }
}

/*
Approach for dfs:
1. Initialize all vertices to WHITE with no parent
2. For each WHITE vertex, start DFS
3. Choose between basic or classification version


*/
void dfs(graph *g, bool classify_edges) {
    // Task 3 solution here
    for (int i = 1; i <= g->nvertices; i++)
    {
        vertices[i].color = WHITE;
        vertices[i].parent = -1;
    }
    time = 0;
    if (classify_edges){
        for (int i = 1; i <= g->nvertices; i++)
        {
            if (vertices[i].color == WHITE){
                dfs_visit_with_classification(g,i);
            }
        }
    }
    else{
        for (int i = 1; i <= g->nvertices; i++)
        {
            if (vertices[i].color == WHITE){
                dfs_visit(g,i);
            }
        }
        
    }
}

void print_dfs_results(graph *g) {
    printf("\nVertex | Discovery | Finish | Parent\n");
    printf("-----------------------------------\n");
    for (int u = 1; u <= g->nvertices; u++) {
        printf("%5d | %9d | %6d | %6d\n", u, vertices[u].d, vertices[u].f, vertices[u].parent);
    }
}

void free_graph(graph *g) {
    for (int i = 1; i <= g->nvertices; i++) {
        edgenode *p = g->edges[i];
        while (p != NULL) {
            edgenode *temp = p;
            p = p->next;
            free(temp);
        }
        g->edges[i] = NULL;
    }
}

int main() {
    // Directed Graph Example
    {
        graph g1;
        initialize_graph(&g1, true);
        g1.nvertices = 6;
        int edges1[][2] = {
            {1, 2}, {1, 3}, {2, 4}, {2, 5}, {3, 6}, {4, 6}, {5, 6}, {6, 3}, {3, 1}, {5, 2}, {2, 4}, {3, 6}, {4, 2}, {6, 1}
        };
        for (int i = 0; i < 14; i++) insert_edge(&g1, edges1[i][0], edges1[i][1], true);
        dfs(&g1, false);
        print_dfs_results(&g1);
        dfs(&g1, true);
        free_graph(&g1);
    }

    // Undirected Graph Example
    {
        graph g2;
        initialize_graph(&g2, false);
        g2.nvertices = 6;
        int edges2[][2] = {
            {1, 2}, {1, 3}, {2, 4}, {3, 4}, {4, 5}, {5, 6}, {2, 6}, {3, 5}
        };
        for (int i = 0; i < 8; i++) insert_edge(&g2, edges2[i][0], edges2[i][1], false);
        dfs(&g2, false);
        print_dfs_results(&g2);
        dfs(&g2, true);
        free_graph(&g2);
    }

    return 0;
}
