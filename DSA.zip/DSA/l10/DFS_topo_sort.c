#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define MAXV 100 // Maximum number of vertices

// Colors for DFS
#define WHITE 0
#define GRAY  1
#define BLACK 2

typedef struct edgenode {
    int y;
    struct edgenode *next;
} edgenode;

typedef struct {
    edgenode *edges[MAXV+1];
    int degree[MAXV+1];
    int nvertices;
    int nedges;
    bool directed;
} graph;

typedef struct {
    int color;
    int d;
    int f;
    int parent;
} dfs_vertex;

int time;
dfs_vertex vertices[MAXV+1];
int topo_sort[MAXV+1]; // Stores topological order
int topo_index; // Tracks position in topo_sort array
bool has_cycle; // Flag to detect cycles

void initialize_graph(graph *g, bool directed) {
    g->nvertices = 0;
    g->nedges = 0;
    g->directed = directed;
    for (int i = 1; i <= MAXV; i++) {
        g->edges[i] = NULL;
        g->degree[i] = 0;
    }
}

void insert_edge(graph *g, int x, int y, bool directed) {
    edgenode *p = malloc(sizeof(edgenode));
    p->y = y;
    p->next = g->edges[x];
    g->edges[x] = p;
    g->degree[x]++;
    g->nedges++;

    if (!directed) {
        edgenode *q = malloc(sizeof(edgenode));
        q->y = x;
        q->next = g->edges[y];
        g->edges[y] = q;
        g->degree[y]++;
    }
}

void print_graph(graph *g) {
    printf("Graph has %d vertices and %d edges\n", g->nvertices, g->nedges);
    printf("Graph is %s\n", g->directed ? "directed" : "undirected");
    for (int i = 1; i <= g->nvertices; i++) {
        printf("%d: ", i);
        edgenode *p = g->edges[i];
        while (p != NULL) {
            printf(" %d", p->y);
            p = p->next;
        }
        printf("\n");
    }
}

/*
Approach for dfs_topo:
1. Mark current node as GRAY (being visited)
2. For each adjacent node:
   - If GRAY: cycle detected (back edge), set has_cycle flag
   - If WHITE: recursively visit
3. Mark current node as BLACK (processed)
4. Add node to topological sort array in reverse finish time order

*/
int time = 0;
void dfs_topo(graph *g, int u) {
    // Task 4 solution here
    vertices[u].color = GRAY;
    time ++;
    vertices[u].d = time;

    edgenode *tmp = g->edges[u];
    while (tmp != NULL)
    {
        if (vertices[tmp->y].color == WHITE){
            vertices[tmp->y].parent = u;
            dfs_topo(g,tmp->y);
        }
        if (vertices[tmp->y].color == GRAY){
            has_cycle = true;
        }
        tmp =tmp->next;
    }

    vertices[u].color = BLACK;
    time ++;
    vertices[u].f = time;
    topo_sort[topo_index] = u;
    topo_index--;
}

/*
Approach for topological_sort:
1. Initialize all vertices to WHITE with no parent
2. Reset cycle flag and set topological index
3. For each WHITE vertex:
   - Perform DFS
   - If cycle detected, print message and return
4. Print topological order if no cycles found

Possible prints:
 -printf("The graph contains a cycle. Topological sorting is not possible.\n");
*/
void topological_sort(graph *g) {
    // Task 5 solution here
    
    has_cycle = false;
    topo_index = g->nvertices;

    for (int i = 1; i <= g->nvertices; i++)
    {
        vertices[i].color = WHITE;
        vertices[i].parent = -1;
    }
    time =0;
    for (int i = 1; i <= g->nvertices; i++)
    {
        if (vertices[i].color == WHITE){
            dfs_topo(g,i);
        }
    }
    

    if (has_cycle){
        printf("The graph contains a cycle. Topological sorting is not possible.\n");
        return;
    }
    else{
        printf("Topological Sort Order: ");
        for (int i = 1; i <= g->nvertices; i++) {
            printf("%d ", topo_sort[i]);
        }
        printf("\n");
    }
    

}

void free_graph(graph *g) {
    for (int i = 1; i <= g->nvertices; i++) {
        edgenode *p = g->edges[i];
        while (p != NULL) {
            edgenode *temp = p;
            p = p->next;
            free(temp);
        }
        g->edges[i] = NULL;
    }
}

int main() {
    graph g;
    initialize_graph(&g, true); // Directed graph
    g.nvertices = 6;

    // Sample edges (DAG)
    int edges[][2] = {
        {1, 2}, {1, 3}, {2, 4}, {2, 5}, {3, 6}, {4, 6}, {5, 6}
    };
    for (int i = 0; i < 7; i++) {
        insert_edge(&g, edges[i][0], edges[i][1], true);
    }

    print_graph(&g);
    topological_sort(&g);

    // Creating a cycle
    insert_edge(&g, 6, 2, true); // Adding an edge that creates a cycle
    printf("\nAfter adding a cycle:\n");
    print_graph(&g);
    topological_sort(&g);

    free_graph(&g);
    return 0;
}
