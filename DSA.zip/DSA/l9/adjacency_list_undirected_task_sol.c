#include <stdio.h>
#include <stdlib.h>

// Structure for an adjacency list node
struct AdjListNode {
    int dest;
    struct AdjListNode* next;
};

// Structure for an adjacency list
struct AdjList {
    struct AdjListNode* head;
};

// Structure for a graph
struct Graph {
    int V;
    struct AdjList* array;
};

// Function to create a new adjacency list node
struct AdjListNode* newAdjListNode(int dest) {
    struct AdjListNode* newNode = (struct AdjListNode*)malloc(sizeof(struct AdjListNode));
    newNode->dest = dest;
    newNode->next = NULL;
    return newNode;
}

// Function to create a graph with V vertices
struct Graph* createGraph(int V) {
    struct Graph* graph = (struct Graph*)malloc(sizeof(struct Graph));
    graph->V = V;
    graph->array = (struct AdjList*)malloc(V * sizeof(struct AdjList));

    for (int i = 0; i < V; i++)
        graph->array[i].head = NULL;

    return graph;
}

// Function to add an edge to the graph
/*
   Approach:
   - Check if the source and destination are valid.
   - Check if the edge already exists.
   - Insert the new edge at the head of the adjacency list of both vertices.

   Possible Prints:
   1. "Invalid edge (src <-> dest): Out of bounds." - Printed if src or dest is invalid.
   2. "Edge (src <-> dest) already exists." - Printed if the edge is already present.
   3. "Edge (src <-> dest) is added." - Printed if the edge is successfully added.
*/
void addEdge(struct Graph* graph, int src, int dest) {
    
    if (src > graph->V || dest > graph->V || src<0 || dest <0){
        fprintf(stderr,"Invalid edge (%d <-> %d): Out of bounds.\n",src ,dest);
        return;
    }
    
    struct AdjListNode* temp = graph->array[src].head;
    while (temp){
        if (temp->dest == dest){
            printf("Edge (%d <-> %d) already exists.\n",src,dest);
            return;
        }
        temp =temp->next; 
    }

    printf("Adding (%d <-> %d)\n", src, dest);
    struct AdjListNode * new_node = newAdjListNode(dest);
    new_node->next = graph->array[src].head;
    graph->array[src].head = new_node;

    struct AdjListNode * new_node2 = newAdjListNode(src);
    new_node2->next = graph->array[dest].head;
    graph->array[dest].head = new_node2;
}

// Function to delete an edge from the graph
/*
   Approach:
   - Check if the source and destination are valid.
   - Search for the edge in the adjacency list.
   - Remove the edge if it exists.

   Possible Prints:
   1. "Invalid edge (src <-> dest): Out of bounds." - Printed if src or dest is invalid.
   2. "Edge (src <-> dest) not found." - Printed if the edge does not exist.
   3. "Edge (src <-> dest) is deleted." - Printed if the edge is successfully removed.
*/
void deleteEdge(struct Graph* graph, int src, int dest) {
    if (src > graph->V || dest > graph->V || src<0 || dest <0){
        fprintf(stderr,"Invalid edge (%d <-> %d): Out of bounds.\n",src ,dest);
        return;
    }
    
    struct AdjListNode* current = graph->array[src].head;
    struct AdjListNode* prev = NULL;

    while (current){
        if (current->dest == dest){
            if (prev == NULL){
                graph->array[src].head = current->next;
            }
            else{
                prev->next = current->next;
            }
        }
        prev = current;
        current = current->next;
    }
 
    current = graph->array[dest].head;
    prev = NULL;
    while (current){
        if (current->dest == src){
            if (prev == NULL){
                graph->array[dest].head = current->next;
            }
            else{
                prev->next = current->next;
            }
        }
        prev = current;
        current = current->next;
    }
    return;

      
}


// Function to check if two edges are adjacent
/*
   Approach:
   - Check if the given vertices are valid.
   - Traverse the adjacency list of the first vertex.
   - If the second vertex is found, the edges are adjacent.

   Possible Prints:
   1. "Invalid vertices (v1, v2): Out of bounds." - Printed if v1 or v2 is invalid.
   2. Print 1 if the edges are adjacent.
   3. Print 0 if the edges are adjacent.
*/
int areEdgesAdjacent(struct Graph* graph, int src1, int dest1, int src2, int dest2) {
    //Task 3 solution.
    if (src1 > graph->V || dest1 > graph->V || src1<0 || dest1 <0){
        fprintf(stderr,"Invalid edge (%d <-> %d): Out of bounds.\n",src1 ,dest1);
        return;
    }
    if (src2 > graph->V || dest2 > graph->V || src2<0 || dest2 <0){
        fprintf(stderr,"Invalid edge (%d <-> %d): Out of bounds.\n",src2 ,dest2);
        return;
    }

    struct AdjListNode* current = graph->array[src1].head;

    while (current){
        if (current->dest == dest1){
            if(dest1 == src2){
                struct AdjListNode* current2 = graph->array[src2].head;
                while (current2)
                {
                    if (current2->dest == dest2){
                        return 1;
                    }
                    current2=current2->next;
                }
            }
        }
        current=current->next;
    }
    return 0;
}

// Function to list all neighbors of a given vertex
/*
   Approach:
   - Check if the vertex is valid.
   - Traverse the adjacency list of the vertex.
   - Print each connected vertex.

   Possible Prints:
   1. "Invalid vertex (vertex): Out of bounds." - Printed if vertex is invalid.
   2. A list of all neighboring vertices.
*/
void listNeighbors(struct Graph* graph, int v) {
    if (v > graph->V || v<0){
        fprintf(stderr,"Invalid edge (%d): Out of bounds.\n",v);
        return;
    }
    printf("Neighbors of vertex %d: ", v);
    struct AdjListNode* current = graph->array[v].head;
    while (current)
    {
       printf("-> %d",current->dest);
       current = current->next; 
    }
    printf("\n");
    
    //Task 4 solution.
}

// Function to list all edges in the graph
/*
   Approach:
   - Traverse the adjacency list of each vertex.
   - Print each edge once to avoid duplicates.

   Possible Prints:
   1. A list of all edges in (vertex1 <-> vertex2) format.
*/void listAllEdges(struct Graph* graph) {
    printf("Edge list:\n");
    for (int v = 0; v < graph->V; v++) {
        struct AdjListNode* temp = graph->array[v].head;
        while (temp) {
            if(temp->dest > v){
               printf(" %d - %d",v, temp->dest);
            }
            temp = temp->next;
        }
        printf("\n");
    }
    //Task 5 solution.
}

// Function to calculate the degree of each vertex
/*
   Approach:
   - Iterate through each vertex in the graph.
   - Count the number of edges in its adjacency list.
   - Print the degree of each vertex.

*/
void calculateDegree(struct Graph* graph) {
    for (int v = 0; v < graph->V; v++) {
        struct AdjListNode* temp = graph->array[v].head;
        int deg = 0;
        while (temp) {
            deg ++;
            temp = temp->next;
        }
        printf("degree of vertex %d : %d\n",v,deg);
    }
    //Task 6 solution.
}

// Function to print the graph
void printGraph(struct Graph* graph) {
    for (int v = 0; v < graph->V; v++) {
        struct AdjListNode* temp = graph->array[v].head;
        printf("Adjacency list of vertex %d\n", v);
        while (temp) {
            printf(" -> %d", temp->dest);
            temp = temp->next;
        }
        printf("\n");
    }
}


// Function to free memory used by the graph
void freeGraph(struct Graph* graph) {
    for (int i = 0; i < graph->V; i++) {
        struct AdjListNode* temp = graph->array[i].head;
        while (temp != NULL) {
            struct AdjListNode* next = temp->next;
            free(temp);
            temp = next;
        }
    }
    free(graph->array);
    free(graph);
}

// Main function to test the graph implementation
int main() {
    int V = 5;
    struct Graph* graph = createGraph(V);
    printf("Initial Graph: \n");
    printGraph(graph);
    printf("--------------------------------------------\n");
    printf("Task 1 Solution:\n");
    addEdge(graph, 0, 1);
    addEdge(graph, 0, 4);
    addEdge(graph, 1, 2);
    addEdge(graph, 1, 3);
    addEdge(graph, 1, 4);
    addEdge(graph, 2, 3);
    addEdge(graph, 3, 4);
    addEdge(graph, 3, 4);
    addEdge(graph, -3, 4);
    addEdge(graph, 3, 6);


    printf("Graph after adding edges:\n");
    printGraph(graph);
    
    printf("--------------------------------------------\n");
    printf("Task 2 Solution:\n");
    printf("\nChecking adjacency of (0 -> 1) and (1 -> 2): %d", areEdgesAdjacent(graph, 0, 1, 1, 2));
    printf("\nChecking adjacency of (0 -> 4) and (4 -> 2): %d", areEdgesAdjacent(graph, 0, 4, 4, 2));
    printf("\nChecking adjacency of (1 -> 3) and (3 -> 2): %d", areEdgesAdjacent(graph, 1, 3, 3, 2));

    
    printf("\n--------------------------------------------\n");
    printf("Task 3 Solution:\n");
    listNeighbors(graph, 1);
    printf("\n");
    listNeighbors(graph, 2);
    printf("\n");

    
    printf("--------------------------------------------\n");
    printf("Task 4 Solution:\n");
    listAllEdges(graph);
    
    
    printf("--------------------------------------------\n");
    printf("Task 5 Solution:\n");
    printf("Vertex Degrees:\n");
    calculateDegree(graph);

    printf("--------------------------------------------\n");
    printf("Task 6 Solution:\n");
    deleteEdge(graph, 1, 4);
    deleteEdge(graph, 1, 4);
    deleteEdge(graph, 6, 4);
    printf("--------------------------------------------\n");
    printf("The adjacency list of the final graph:\n");
    printGraph(graph);
    freeGraph(graph);
    return 0;
}
