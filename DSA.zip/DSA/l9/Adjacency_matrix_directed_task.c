#include <stdio.h>
#include <stdlib.h>

// Structure for a directed graph
struct Graph {
    int V;
    int** matrix;
};

// Function to create a graph with V vertices
struct Graph* createGraph(int V) {
    struct Graph* graph = (struct Graph*)malloc(sizeof(struct Graph));
    graph->V = V;

    graph->matrix = (int**)malloc(V * sizeof(int*));
    for (int i = 0; i < V; i++) {
        graph->matrix[i] = (int*)malloc(V * sizeof(int));
        for (int j = 0; j < V; j++) {
            graph->matrix[i][j] = 0;
        }
    }
    return graph;
}

// Function to free allocated memory
void freeGraph(struct Graph* graph) {
    for (int i = 0; i < graph->V; i++) {
        free(graph->matrix[i]);
    }
    free(graph->matrix);
    free(graph);
}

// Function to add a directed edge to the graph
/*
   Approach:
   - Check if the source and destination are valid.
   - Check if the edge already exists.
   - If not, add the edge.

   Possible Prints:
   1. "Invalid edge (src -> dest): Out of bounds." - Printed if src or dest is invalid.
   2. "Edge (src -> dest) is already present." - Printed if edge already exists.
   3. "Edge (src -> dest) added successfully." - Printed if edge is added.
*/
void addEdge(struct Graph* graph, int src, int dest) {
    if (src < 0 || src > graph->V || dest < 0 || dest > graph->V){
        printf("Invalid edge (%d -> %d): Out of bounds.\n",src,dest);
        return;
    }

    if (graph->matrix[src][dest] == 1){
       printf("Edge (%d <-> %d) already exists.\n",src,dest);
       return;
    }
    printf("Adding (%d -> %d)\n", src, dest);
    graph->matrix[src][dest] = 1;
    //Task 1 solution.
}

// Function to delete an edge from the graph
/*
   Approach:
   - Check if the source and destination are valid.
   - Check if the edge exists in the adjacency matrix.
   - If found, remove the edge.

   Possible Prints:
   1. "Invalid edge deletion (src -> dest): Out of bounds." - Printed if src or dest is invalid.
   2. "Edge (src -> dest) does not exist." - Printed if edge is not found.
   3. "Edge (src -> dest) deleted successfully." - Printed if edge is successfully removed.
*/
void deleteEdge(struct Graph* graph, int src, int dest){
    if (src < 0 || src > graph->V || dest < 0 || dest > graph->V){
        printf("Invalid edge (%d -> %d): Out of bounds.\n",src,dest);
        return;
    }
    if (graph->matrix[src][dest] == 0){
        printf("Edge (%d <-> %d) does not exist.\n",src,dest);
        return;
    }
    printf("Deleting (%d -> %d)\n", src, dest);
    graph->matrix[src][dest] = 0;
    //Task 2 solution.
}

// Function to compute in-degree and out-degree of each vertex
/*
   Approach:
   - Iterate over each row to calculate out-degree.
   - Iterate over each column to calculate in-degree.

   Possible Prints:
   1. "Vertex v: In-Degree = x, Out-Degree = y" - Printed for each vertex.
*/
void computeDegree(struct Graph* graph) {
    for(int v = 0; v < graph->V; v++){
        int in = 0;
        int out = 0;
        for (int i = 0; i < graph->V; i++)
        {
            if (graph->matrix[v][i] == 1){
                out ++;
            }
        }
        for (int i = 0; i < graph->V; i++){
            if (graph->matrix[i][v] == 1)
            {
                in ++;
            }
            
        }
        printf("Vertex %d: In-Degree = %d, Out-Degree = %d\n",v,in,out);
    }
    //Task 3 solution.

}


// Function to check if two edges are adjacent
/*
   Approach:
   - Check if both edges exist in the adjacency matrix.
   - If either edge is missing, return 0 (not adjacent).
   - Otherwise, check if they share a common vertex.

   Possible Prints:
   1. It returns 0 if at least one of the edges does not exist.
   2. It returns 1 if the edges are adjacent (share a common vertex).
*/
int areEdgesAdjacent(struct Graph* graph, int src1, int dest1, int src2, int dest2) {
    if (graph->matrix[src1][dest1] == 1 && graph->matrix[src2][dest2]==1 && dest1 == src2){
        return 1;
    }
    return 0;
}



// Function to list the neighbors of a vertex
/*
   Approach:
   - Validate if the vertex is within bounds.
   - Iterate over all vertices and check for outgoing edges.
   - Print all directly connected vertices.

   Possible Prints:
   1. "Invalid vertex v" - Printed if v is out of bounds.
   2. "Neighbors of vertex v: x y z" - Printed with all neighbors.
*/
void listNeighbors(struct Graph* graph, int v) {
    if (v < 0 || v > graph->V){
        printf("Invalid vertex %d\n",v);
        return;
    }
    printf("Neighbors of vertex %d: ",v);
    for (int i = 0; i < graph->V; i++)
    {
        if (graph->matrix[v][i] == 1){
            printf("%d ",i);
        }
    }
    printf("\n");
}

// Function to print all edges in the graph
/*
   Approach:
   - Iterate through the adjacency matrix.
   - Print all pairs (i, j) where an edge exists.

   Possible Prints:
   2. "(src -> dest)" - Printed for each edge in the graph.
*/
void printEdges(struct Graph* graph) {
    printf("Edge List: ");
    for (int i = 0; i < graph->V; i++)
    {
       for (int j = 0; j < graph->V; j++)
       {
            if (graph->matrix[i][j]==1){
                printf("(%d -> %d), ",i,j);
            }
       }
        
    }
    printf("\n");
    
}


// Function to print the adjacency matrix
void printGraph(struct Graph* graph) {
    for (int i = 0; i < graph->V; i++) {
        for (int j = 0; j < graph->V; j++) {
            printf("%d ", graph->matrix[i][j]);
        }
        printf("\n");
    }
}

// Main function to test the graph implementation
int main() {
    int V = 5;
    struct Graph* graph = createGraph(V);
    printf("Initial Graph: \n");
    printGraph(graph);
    printf("--------------------------------------------\n");
    printf("Task 1 Solution:\n");
    addEdge(graph, 0, 1);
    addEdge(graph, 0, 4);
    addEdge(graph, 1, 2);
    addEdge(graph, 1, 3);
    addEdge(graph, 1, 4);
    addEdge(graph, 2, 3);
    addEdge(graph, 3, 4);
    addEdge(graph, 1, 4);
    addEdge(graph, 1, 4);
    addEdge(graph, -1, 4);
    addEdge(graph, 1, 6);
    printf("Final Graph Adjacency Matrix:\n");
    printGraph(graph);
    printf("--------------------------------------------\n");
    printf("Task 2 Solution:\n");
    printEdges(graph);
    
    
    printf("--------------------------------------------\n");
    printf("Task 3 Solution:\n");
    printf("Vertex Degrees:\n");
    computeDegree(graph);
    
    
    printf("--------------------------------------------\n");
    printf("Task 4 Solution:\n");
    listNeighbors(graph, 1);
    listNeighbors(graph, 2);
    
    
    
    printf("--------------------------------------------\n");
    printf("Task 5 Solution:");
    printf("\nChecking adjacency of (0 -> 1) and (1 -> 2): %d", areEdgesAdjacent(graph, 0, 1, 1, 2));
    printf("\nChecking adjacency of (0 -> 4) and (4 -> 2): %d", areEdgesAdjacent(graph, 0, 4, 4, 2));
    printf("\nChecking adjacency of (1 -> 3) and (3 -> 2): %d", areEdgesAdjacent(graph, 1, 3, 3, 2));

    
    
    printf("\n--------------------------------------------\n");
    printf("Task 6 Solution:\n");
    deleteEdge(graph, 5, 6);
    deleteEdge(graph, 3, 4);
    deleteEdge(graph, 3, 4);
    printf("--------------------------------------------\n");
    printf("The adjacency matrix of the final graph:\n");

    printGraph(graph);
    
    
    freeGraph(graph);
    return 0;
}

