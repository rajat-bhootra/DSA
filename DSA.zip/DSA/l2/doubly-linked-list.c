/*
	Course:		CS2130 DSA Lab 
	Semester:	2025 Jan-Apr
	Lab:		02 | Linked Lists
	Task Set:	2 | Doubly Linked Lists (dLL)

	Aim: 		Implement a doubly linked list with some basic functions.
	Assume:		All data to be stored are integers
*/

#include <limits.h>	// For INT_MAX
#include <stdio.h>
#include <stdlib.h>	// Needed for malloc, free etc

/* 	Unlike a singly linked list, it is not easy to define a doubly linked
	list in a recursive style. So we need two stucts - 
		(a) One struct for node, which holds the data and two pointers - 
			one to the next node and one to the previous node.
		(b)	One struct for the list itself - which contains two pointers -
			one to the fist node in the list and one to the last.
	When implementing a dLL the following two additional functionalities
	(one transparent one opaque) are needed to make a dLL useful.
		(a) insert_at_pos(), get_from_pos(), and delete_at_pos() functions
			should accept negative integers also as position argument. 
			-1 : last node (tail), -2 is previous to -1 and so on.
		(b) if the given position is negative, the list should be traversed
			backwards from the tail. This speeds up data access in the 
			second half of large lists 
*/
typedef struct node{
	int 			data;	// The data stored in the node
	struct node*	prev;	// Pointer to previous node
	struct node*	next;	// Pointer to next node
} node;

typedef struct dLL{
	struct node*	head;	// Pointer to first node in the list
	struct node*	tail;	// Pointer to last node in the list
} dLL;

node* create_node(int data, node *next, node *prev) {
/*
	Inputs:
		1. 	Data for the new node to be inserted
		2.	A node pointer to be set as the next pointer of the new node
		2.	A node pointer to be set as the prev pointer of the new node
	Actions:
		1.	Memory required for a new node is allotted.
		2.	The data and the two pointers of the new node are set from the inputs
	Error Response:
		1.	Prints "Error: Memory allocation for new node failed." to stderr if
			malloc fails.	
		2.	Returns NULL if the new node cannot be created
*/
	node* new = (node *) malloc(sizeof(node));
	if(new == NULL) {
		fprintf(stderr, "Error: Memory allocation for new node failed\n");
		return NULL;
		}
	new->data = data;
	new->next = next;
	new->prev = prev;
	return new;
}

dLL* create_dLL(node *head, node *tail) {
/*
	Inputs:
		2.	A pointer to the head of the list (NULL is allowed)
		2.	A pointer to the tail of the list (NULL is allowed)
	Actions:
		1. 	A new dLL struct with the given head and tail is returned
*/
	dLL* list = (dLL *) malloc(sizeof(dLL));
	if(list == NULL) {
		fprintf(stderr, "Error: Memory allocation for dLL failed\n");
		return NULL;
		}
	list->head = head;
	list->tail = tail;
	return list;
}


/* Task 6. 
	Copy all the functions (including main) that you have in simple-linked-list.c
	here and edit all the COMMENTS to reflect the changes needed.
*/

dLL* insert_at_start(int data, dLL* list) {
/*
	Inputs:
		1. 	Data for the new node to be inserted
		2.	A list
	Actions:
		1.	A new node with the received data is inserted at the head of the
			received list
		2.	The pointer to this new node (which is effectively the new head of
			the list) is returned.
	Error Response:
		1.	Prints "Error: Insertion at start failed." to stderr
		2.	Returns NULL if the new node cannot be created
*/
	dLL* new = create_node(data,list->head,NULL);
	if(new == NULL) {
		fprintf(stderr, "Error: Insertion at start failed\n");
		return NULL;
		}
	list->head->prev = new;
	list->head = new;
	return list;
}

dLL *insert_at_end(int data ,dLL *list){
    dLL* new = create_node(data,NULL,list->tail);
	if(new == NULL) {
		fprintf(stderr, "Error: Insertion at start failed\n");
		return NULL;
		}
	list->tail->next = new;
	list->tail = new;
	return list; 
}
// }

void print_list(dLL *list) {
/*
	Input:	A list
	Actions:
		Prints the data in the linked list from start to end
		in the format:  D0 - D1 - ... - Dn - NULL
*/

    node *current = list->head;
    while (current != NULL)
	{
		printf("%d <-> ",current->data);
		current = current->next;
	}
	
	printf("NULL\n");
}

void print_list_reverse(dLL *list){
     node *current = list->tail;
	 while (current != NULL)
	 {
		printf("%d <->",current->data);
	    current = current->prev;
	 }
	 
	 printf("NUll\n");
}

/* Task 7. 
	Edit the code inside of each function to implement the functionality on doubly
	linked lists. You can assume that position indices will still be non-negative.
	Hence you need to do forward traversal for this Task. (Negative indices and
	reverse traversals is the next Task.
*/



/* 
	Task 8. Allow negative indices and implement reverse traversal for them.
	(a) insert_at_pos(), get_from_pos(), and delete_at_pos() functions
		should accept negative integers also as position argument. 
		-1 : last node (tail), -2 is previous to -1 and so on.
	(b) if the given position is negative, the list should be traversed
		backwards from the tail. This speeds up data access in the 
		second half of large lists 
	(c) Modify the Testing loops for these functions in main to test for
		negative indices also.
*/

/* 	This main() only contains stuff to test the data structures
	Replace this with the main from simple-linked-list.c
*/
int main() {

    int i;
        
	node *new = create_node(0, NULL, NULL);
	dLL* list = create_dLL(new, new);
	dLL * templist=create_dLL(new, new);

	printf("============================\n");
	printf("### Testing different insert funcitons\n\n");

	// Test for: insert_at_start() and insert_at_end(). Even numbers inserted at start and odd numbers inserted at end.
	printf("Testing insert_at_start() and insert_at_end(). Even numbers inserted at start and odd numbers inserted at end\n");
	for(i = 1; i <=10; i++)
	 {
		if(i%2==0)
			{
			list = insert_at_start(i, list);
			print_list(list);
			}
		else
			{
			list = insert_at_end(i, list);
				print_list(list);
			}
	
	}	
	printf("============================\n");
	
	printf("Testing print_list_reverse()\n");
	print_list_reverse(list);	
	
	// // Test for: insert_at_pos()
	// printf("============================\n");
	// print_list(list);
	// printf("Testing insert_at_pos(). Multiples of 3 inserted at every 4th position\n");
	// for(i = 0; i < 4; i++) {
	// 	list = insert_at_pos(i*3, list, i*4);
	// 	print_list(list);
	// }
	// // Testing insert outside of the range
	// printf("============================\n");
	// printf("Testing insert_at_pos() for pos out of range\n");
	// templist = insert_at_pos(25, list, 25);
	// if(templist == NULL) {
	// 	printf("NULL pointer returned.\n");
	// }
	// printf("============================\n\n");
	
	// // Test : get_from_pos()
	// printf("============================\n");
	// printf("### Testing different get functions\n\n");

	// printf("Testing get_from_pos() where pos is non negative\n");
	// print_list(list);
	// for(i = 0; i < 25; i += 4)
	// {
	// 	printf("Data at pos %d is %d\n", i, get_from_pos(list, i));
	// }	

	// printf("Testing get_from_pos() where pos is negative\n");
	// print_list(list);
	// for(i = -1; i > -15; i -= 4)
	// {
	// 	printf("Data at pos %d is %d\n", i, get_from_pos(list, i));
	// }	
	// printf("============================\n\n");
	
	// printf("============================\n");
	// printf("### Testing find()\n");
	// print_list(list);
	// for(i = 0; i <= 12; i+=3) {
	// 	printf("Position of %d is %d\n", i, find(i, list));
	// }
	// printf("============================\n\n");
	
	// printf("============================\n");
	// printf("### Testing different delete functions\n\n");

	// // Test : delete_first()
	// print_list(list);
	// printf("Testing delete_first() \n");
	// list= delete_first(list);
	// print_list(list);
	
	// // Test : delete_last()
	// printf("Testing delete_last()\n");
	// list= delete_last(list);
	// print_list(list);
	
	// // Test for : delete_at_pos()
	// printf("Testing delete_at_pos()\n");
	// print_list(list);
	// for(i = 0; i <= 10; i += 5) {
	// 	printf("Deleting data (%d) at pos %d\n", get_from_pos(list, i), i);
	// 	list = delete_at_pos(list, i);
	// 	print_list(list);
	// }
	// printf("Testing delete_at_pos() for negative index\n");
	// for(i = -1; i > -7; i -= 3) {
	// 	printf("Deleting data (%d) at pos %d\n", get_from_pos(list, i), i);
	// 	list = delete_at_pos(list, i);
	// 	print_list(list);
	// }
	// // Testing delete outside of the range
	// i = 10;
	// printf("Deleting data (%d) at pos %d\n", get_from_pos(list, i), i);
	// templist = delete_at_pos(list, i);
	// if(templist == NULL) {
	// 	printf("NULL pointer returned.\n");
	// }
	// printf("============================\n\n");
	
	// return 0;
}
