#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define MAXV 100
#define WHITE 0
#define GRAY  1
#define BLACK 2

typedef struct edgenode {
    int y;
    struct edgenode *next;
} edgenode;

typedef struct {
    edgenode *edges[MAXV + 1];
    int degree[MAXV + 1];
    int nvertices;
    int nedges;
    bool directed;
} graph;

typedef struct {
    int color;
    int distance;
    int parent;
} bfs_vertex;

bfs_vertex vertices[MAXV + 1];

typedef struct {
    int q[MAXV];
    int first, last, count;
} queue;

void init_queue(queue *q) {
    q->first = 0;
    q->last = MAXV - 1;
    q->count = 0;
}

void enqueue(queue *q, int x) {
    if (q->count >= MAXV)
        printf("Warning: queue overflow enqueue x=%d\n", x);
    else {
        q->last = (q->last + 1) % MAXV;
        q->q[q->last] = x;
        q->count++;
    }
}

int dequeue(queue *q) {
    if (q->count <= 0) {
        printf("Warning: empty queue dequeue.\n");
        return -1;
    }
    int x = q->q[q->first];
    q->first = (q->first + 1) % MAXV;
    q->count--;
    return x;
}

void initialize_graph(graph *g, bool directed) {
    g->nvertices = 0;
    g->nedges = 0;
    g->directed = directed;
    for (int i = 1; i <= MAXV; i++) {
        g->edges[i] = NULL;
        g->degree[i] = 0;
    }
}

void insert_edge(graph *g, int x, int y, bool directed) {
    edgenode *p = malloc(sizeof(edgenode));
    p->y = y;
    p->next = g->edges[x];
    g->edges[x] = p;
    g->degree[x]++;
    g->nedges++;

    if (!directed) {
        edgenode *q = malloc(sizeof(edgenode));
        q->y = x;
        q->next = g->edges[y];
        g->edges[y] = q;
        g->degree[y]++;
    }
}

void print_graph(graph *g) {
    printf("Graph has %d vertices and %d edges\n", g->nvertices, g->nedges);
    printf("Graph is %s\n", g->directed ? "directed" : "undirected");
    for (int i = 1; i <= g->nvertices; i++) {
        printf("%d:", i);
        edgenode *p = g->edges[i];
        while (p != NULL) {
            printf(" %d", p->y);
            p = p->next;
        }
        printf("\n");
    }
}

/*
Task 1: BFS Traversal

Approach:
1. Set all vertices as unvisited (WHITE), distance -1, and parent -1
2. Set source as GRAY, distance 0
3. Use a queue to visit nodes and update neighbors
4. For each neighbor, if WHITE, mark as GRAY, set parent and distance, enqueue
*/
void bfs(graph *g, int start) {
    // Task 1: Implement BFS traversal here
    for (int i = 1; i <= g->nvertices; i++)
    {
        vertices[i].color = WHITE;
        vertices[i].distance = -1;
        vertices[i].parent = -1;
    }

    vertices[start].color = GRAY;
    vertices[start].distance = 0;

    queue q;
    init_queue(&q);

    enqueue(&q,start);

    while (q.count > 0)
    {
        int u = dequeue(&q);
        edgenode *tmp = g->edges[u];
        while (tmp)
        {
            if (vertices[tmp->y].color == WHITE){
                vertices[tmp->y].color = GRAY;
                vertices[tmp->y].distance = vertices[u].distance +1;
                vertices[tmp->y].parent = u;
                enqueue(&q,tmp->y);
            }
            tmp= tmp->next;
        }
        
        vertices[u].color = BLACK;
    }
    
    
}

/*
Task 2: Print Shortest Paths

Approach:
1. Use parent array from BFS to backtrack from destination to source
2. Recursively print the path
3. Handle unreachable nodes
 
Possible Output:
 Shortest paths from vertex 1:
 1 to 1: 1
 1 to 2: 1 -> 2
 1 to 3: 1 -> 3
 1 to 4: 1 -> 3 -> 4
 1 to 5: 1 -> 3 -> 5
 1 to 6: 1 -> 2 -> 6
*/
void print_path(int start, int v) {
    // Task 2: Implement recursive shortest path printing here
    if (start != v)
    {
        print_path(start,vertices[v].parent);
        printf("->");
    }
    printf("%d",v);
}

void print_bfs_result(graph *g, int start) {
    printf("\nVertex   | Distance | Predecessor\n");
    printf("----------------------------------\n");
    for (int i = 1; i <= g->nvertices; i++) {
        printf("%-9d| %-9d| %-10d\n", i, vertices[i].distance, vertices[i].parent);
    }

    printf("\nShortest paths from vertex %d:\n", start);
    for (int i = 1; i <= g->nvertices; i++) {
        printf("%d to %d: ", start, i);
        if (vertices[i].parent == -1 && i != start)
            printf("No path");
        else
            print_path(start, i);
        printf("\n");
    }
}

/*
Task 3: Check Bipartite using BFS

Approach:
1. Assign alternating colors (0/1) to neighbors
2. If any two adjacent nodes have same color → Not bipartite
3. Use BFS from all unvisited nodes (for disconnected graphs)
*/
bool is_bipartite(graph *g, int start) {
    // Task 3: Implement BFS-based bipartite check here
    int color_arr[MAXV];
    for (int i = 0; i < MAXV; i++)
    {
        color_arr[i] = -1;
    }

    queue q;
    init_queue(&q);
    enqueue(&q,start);
    color_arr[start]=0;
    
    while (q.count > 0)
    {
        int u = dequeue(&q);
        edgenode *tmp = g->edges[u];

        while (tmp)
        {
            if (color_arr[tmp->y] == -1){
                if (color_arr[u] == 0){
                    color_arr[tmp->y] == 1;
                }
                else if (color_arr[u] == 1)
                {
                    color_arr[tmp->y] == 0;
                }
            }
            if (color_arr[u] == color_arr[tmp->y]){
                return 0;
            }
            tmp = tmp->next;
        }
        
    }
    
    
    return 1;
}

void free_graph(graph *g) {
    for (int i = 1; i <= g->nvertices; i++) {
        edgenode *p = g->edges[i];
        while (p) {
            edgenode *tmp = p;
            p = p->next;
            free(tmp);
        }
        g->edges[i] = NULL;
    }
}

int main() {
    graph g;
    initialize_graph(&g, false);
    g.nvertices = 6;

    int edges[][2] = {
        {1, 2}, {1, 3}, {2, 4}, {3, 4}, {4, 5}, {5, 6}, {2, 6}
    };

    for (int i = 0; i < 7; i++)
        insert_edge(&g, edges[i][0], edges[i][1], false);

    print_graph(&g);

    int start = 1;

    bfs(&g, start);                  // Task 1
    print_bfs_result(&g, start);     // Task 2

    if (is_bipartite(&g, start))     // Task 3
        printf("\nThe graph is Bipartite.\n");
    else
        printf("\nThe graph is not Bipartite.\n");

    free_graph(&g);
    return 0;
}
