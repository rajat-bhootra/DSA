#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define MAXV 1000

// Colors for DFS
#define WHITE 0
#define GRAY  1
#define BLACK 2

typedef struct edgenode {
    int y;
    int weight;
    struct edgenode *next;
} edgenode;

typedef struct {
    edgenode *edges[MAXV + 1];
    int degree[MAXV + 1];
    int nvertices;
    int nedges;
    bool directed;
} graph;

typedef struct {
    int color;
    int d;
    int f;
    int parent;
} dfs_vertex;

dfs_vertex vertices[MAXV + 1];
int time;

void initialize_graph(graph *g, bool directed) {
    g->nvertices = 0;
    g->nedges = 0;
    g->directed = directed;
    for (int i = 0; i <= MAXV; i++) {
        g->degree[i] = 0;
        g->edges[i] = NULL;
    }
}

void insert_edge(graph *g, int x, int y, bool directed) {
    edgenode *p = (edgenode *)malloc(sizeof(edgenode));
    p->y = y;
    p->weight = 0;
    p->next = g->edges[x];
    g->edges[x] = p;
    g->degree[x]++;
    
    if (!directed)
        insert_edge(g, y, x, true);
    else
        g->nedges++;
}

void dfs_visit1(graph *g, int v, int *order, int *order_index) {
    vertices[v].color = GRAY;
    vertices[v].d = ++time;

    for (edgenode *p = g->edges[v]; p != NULL; p = p->next) {
        int y = p->y;
        if (vertices[y].color == WHITE) {
            vertices[y].parent = v;
            dfs_visit1(g, y, order, order_index);
        }
    }

    vertices[v].color = BLACK;
    vertices[v].f = ++time;
    order[(*order_index)++] = v;
}

// ==== TASK 4: DFS Visit on Transpose ====
// Approach:
// - Mark the current vertex as GRAY.
// - Assign the current component number to this vertex.
// - Recursively explore all adjacent WHITE vertices.
// - After visiting all neighbors, mark the current vertex as BLACK.
void dfs_visit2(graph *g, int v, int component[], int comp_num) {
    // Task 4 solution here
    vertices[v].color = GRAY;
    component[v] = comp_num;
    edgenode *tmp = g->edges[v];
    while (tmp)
    {
        if (vertices[tmp->y].color == WHITE){
            dfs_visit2(g,tmp->y,component, comp_num);
        }
        tmp = tmp->next;
    }
    vertices[v].color = BLACK;
}

// ==== TASK 5: Transpose Graph ====
// Approach:
// - Initialize a new graph `gt` as the transpose.
// - For each edge u → v in the original graph `g`, insert an edge v → u in `gt`.
// - Return the transposed graph.
graph transpose_graph(graph *g) {
    // Task 5 solution here
    graph gt;
    initialize_graph(&gt, true);
    gt.nvertices = g->nvertices;
    for (int i = 1; i <=g->nvertices; i++)
    {
        edgenode *tmp = g->edges[i];
        while (tmp)
        {
            insert_edge(&gt, tmp->y, i, true);
            tmp = tmp->next;
        }
        
    }
    
    return gt; //you may need to remove it
}

// ==== TASK 3: Kosaraju’s Algorithm ====
// Approach:
// - Initialize all vertices as WHITE and perform DFS on the original graph.
// - Track finishing times by storing vertices in an array as they finish.
// - Transpose the original graph.
// - Reinitialize all vertices as WHITE again.
// - Process vertices in decreasing order of finishing time.
// - Each DFS tree in the transposed graph corresponds to one strongly connected component.
void strongly_connected_components(graph *g, int component[], int *num_components) {
    // Task 6 solution here
    for (int i = 1; i <=g->nvertices; i++)
    {
        vertices[i].color = WHITE;
    }

    int order[MAXV];
    int order_ind = 0;
    for (int i = 1; i <= g->nvertices; i++)
    {
        if (vertices[i].color == WHITE){
            dfs_visit1(g, i, order, &order_ind);
        }
    }
    
    graph trans = transpose_graph(g);
    for (int i = 1; i <=g->nvertices; i++)
    {
        vertices[i].color = WHITE;
    }
    
    int j = order_ind -1;
    while (j >= 0)
    {
        if (vertices[order[j]].color == WHITE){
            dfs_visit2(&trans, order[j], component, *num_components);
            (*num_components)++;
        }
        j--;
    }
    
}

void print_graph(graph *g, const char *msg) {
    printf("%s\n", msg);
    for (int i = 1; i <= g->nvertices; i++) {
        printf("%d: ", i);
        for (edgenode *p = g->edges[i]; p != NULL; p = p->next)
            printf("%d ", p->y);
        printf("\n");
    }
    printf("\n");
}

void print_discovery_and_finishing_times(graph *g) {
    printf("| Vertex | Discovery Time | Finishing Time |\n");
    printf("|--------|----------------|----------------|\n");
    for (int i = 1; i <= g->nvertices; i++) {
        printf("|   %2d   |       %2d       |       %2d       |\n", i, vertices[i].d, vertices[i].f);
    }
    printf("\n");
}

void free_graph(graph *g) {
    for (int i = 1; i <= g->nvertices; i++) {
        edgenode *p = g->edges[i];
        while (p != NULL) {
            edgenode *temp = p;
            p = p->next;
            free(temp);
        }
    }
}

int main() {
    graph g;
    int component[MAXV + 1];
    int num_components;

    initialize_graph(&g, true);
    g.nvertices = 5;

    insert_edge(&g, 1, 2, true);
    insert_edge(&g, 2, 3, true);
    insert_edge(&g, 3, 1, true);
    insert_edge(&g, 2, 4, true);
    insert_edge(&g, 4, 5, true);

    print_graph(&g, "Adjacency list of the input graph:");

    strongly_connected_components(&g, component, &num_components);

    print_discovery_and_finishing_times(&g);

    graph gt = transpose_graph(&g);
    print_graph(&gt, "Adjacency list of the transposed graph:");

    
    printf("Total strongly connected components: %d\n", num_components);
    for (int i = 0; i < num_components; i++) {
        printf("Component %d: ", i);
        for (int v = 1; v <= g.nvertices; v++) {
            if (component[v] == i)
                printf("%d ", v);
        }
        printf("\n");
    }

    free_graph(&g);
    return 0;
}
