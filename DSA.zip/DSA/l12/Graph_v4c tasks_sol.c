#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define MAXV 1000
#define WHITE 0
#define GRAY 1
#define BLACK 2

typedef struct edgenode {
    int y;
    int weight;
    bool visited;
    struct edgenode *next;
} edgenode;

typedef struct {
    edgenode *edges[MAXV + 1];
    int degree[MAXV + 1];
    int nvertices;
    int nedges;
    bool directed;
} graph;

// DFS vertex structure to hold additional state during DFS
typedef struct dfs_vertex {
    int color;      // WHITE, GRAY, or BLACK
    int parent;     // Parent of the vertex in DFS tree
    int discovery_time; // Time when the vertex was first visited
} dfs_vertex;

dfs_vertex dfs_state[MAXV + 1]; // Array to store DFS state for each vertex

// Initialize the graph
void initialize_graph(graph *g, bool directed) {
    g->nvertices = 0;
    g->nedges = 0;
    g->directed = directed;
    for (int i = 1; i <= MAXV; i++) {
        g->degree[i] = 0;
        g->edges[i] = NULL;
    }
}

// Insert an edge
void insert_edge(graph *g, int x, int y, bool directed) {
    edgenode *p = malloc(sizeof(edgenode));
    p->y = y;
    p->weight = 0;
    p->visited = false;
    p->next = g->edges[x];
    g->edges[x] = p;
    g->degree[x]++;
    if (!directed)
        insert_edge(g, y, x, true);
    else
        g->nedges++;
}

// DFS Visit using dfs_vertex structure
void dfs_visit(graph *g, int v, int *time) {
    dfs_state[v].color = GRAY;
    dfs_state[v].discovery_time = ++(*time);
    edgenode *p = g->edges[v];
    while (p != NULL) {
        if (dfs_state[p->y].color == WHITE) {
            dfs_state[p->y].parent = v;
            dfs_visit(g, p->y, time);
        }
        p = p->next;
    }
    dfs_state[v].color = BLACK;
}

// Approach for is_connected function:
// The function should check if the graph is connected by performing a Depth First Search (DFS).
// - The graph is connected if all vertices are reachable from any starting vertex.
// - Implement a DFS starting from vertex 1, and mark all the vertices visited.
// - After the DFS, if any vertex remains unvisited, return false (disconnected), otherwise return true (connected).
//
// Expected output:
// - Return true if the graph is connected, otherwise false.
bool is_connected(graph *g) {
    // Task 1
    for ( int i = 1; i <= g->nvertices; i++)
    {
        dfs_state[i].color = WHITE;
    }

    int time = 0;
    dfs_visit(g,1,&time);
    bool ans = true;
    for (int i = 1; i <= g->nvertices; i++)
    {
        if (dfs_state[i].color == WHITE)
        {
            ans = false;
        }
        
    }
    return ans;
}

// Approach for is_eulerian function:
// The function should check if the graph has an Eulerian circuit.
// - A graph has an Eulerian circuit if it is connected and all vertices have an even degree.
// - First, check if the graph is connected using the `is_connected` function.
// - Then, check that every vertex has an even degree. If any vertex has an odd degree, the graph cannot have an Eulerian circuit.
//
// Expected output:
// - Return true if the graph has an Eulerian circuit, otherwise false.
bool is_eulerian(graph *g) {
    // Task 2
    if (!is_connected(g)){
        return false;
    }
    for (int i = 1; i <= g->nvertices; i++)
    {
        if (g->degree[i]%2 != 0){
            return false;
        }
    }
    
    return true;
}

// Approach for print_eulerian_util function:
// This function should print the Eulerian circuit if one exists.
// - If an Eulerian circuit exists, the function should recursively visit and print each vertex, starting from any vertex with an edge.
// - Each edge should be visited exactly once, so edges need to be marked as visited after being traversed.
// - The output should print the vertices of the Eulerian circuit in the order they are visited.
//
// Expected output:
// - The Eulerian circuit as a sequence of vertices printed in the order of traversal.
void print_eulerian_util(graph *g, int u) {
    // Task 3
    edgenode *tmp = g->edges[u];
    while (tmp!=NULL)
    {
        if(!tmp->visited){
            tmp->visited = true;
            edgenode *tmp2 = g->edges[tmp->y];
            while (tmp2)
            {
                if (!tmp2->visited && tmp2->y == u){
                    tmp2->visited = true;
                    break;
                }
                tmp2=tmp2->next;
            }
            
            print_eulerian_util(g,tmp->y);
            printf("%d -> ", tmp->y);
        }
        tmp=tmp->next;
    }
    
}

// Wrapper to print Eulerian circuit
void print_eulerian_circuit(graph *g) {
    int start = 1;
    for (int i = 1; i <= g->nvertices; i++) {
        if (g->degree[i] > 0) {
               start = i;
            break;
        }
    }
    printf("Eulerian Circuit:\n");
    print_eulerian_util(g,start);
    printf("%d\n",start);
}

// Load hardcoded test case into graph
int main() {
    graph g;

    // ---- Test Case 1: Eulerian Circuit ----
    printf("Test Case 1: Eulerian Circuit\n");
    initialize_graph(&g, false);
    g.nvertices = 5;
    insert_edge(&g, 1, 2, false);
    insert_edge(&g, 2, 3, false);
    insert_edge(&g, 3, 4, false);
    insert_edge(&g, 4, 5, false);
    insert_edge(&g, 5, 1, false);

    printf("Is Connected? %s\n", is_connected(&g) ? "Yes" : "No");
    printf("Is Eulerian? %s\n", is_eulerian(&g) ? "Yes" : "No");
    if (is_eulerian(&g))
        print_eulerian_circuit(&g);
    printf("\n");

    // ---- Test Case 2: Connected but Not Eulerian ----
    printf("Test Case 2: Connected but Not Eulerian\n");
    initialize_graph(&g, false);
    g.nvertices = 4;
    insert_edge(&g, 1, 2, false);
    insert_edge(&g, 2, 3, false);
    insert_edge(&g, 3, 4, false);
    insert_edge(&g, 4, 1, false);
    insert_edge(&g, 1, 3, false); // Makes degrees uneven

    printf("Is Connected? %s\n", is_connected(&g) ? "Yes" : "No");
    printf("Is Eulerian? %s\n", is_eulerian(&g) ? "Yes" : "No");
    if (is_eulerian(&g))
        print_eulerian_circuit(&g);
    printf("\n");

    // ---- Test Case 3: Not Connected (isolated vertex) ----
    printf("Test Case 3: Not Connected (isolated vertex)\n");
    initialize_graph(&g, false);
    g.nvertices = 5;
    insert_edge(&g, 1, 2, false);
    insert_edge(&g, 2, 3, false);
    insert_edge(&g, 3, 1, false);
    // Vertex 4 and 5 are isolated

    printf("Is Connected? %s\n", is_connected(&g) ? "Yes" : "No");
    printf("Is Eulerian? %s\n", is_eulerian(&g) ? "Yes" : "No");
    if (is_eulerian(&g))
        print_eulerian_circuit(&g);
    printf("\n");

    return 0;
}
