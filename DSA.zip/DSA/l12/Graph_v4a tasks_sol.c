#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define MAXV 1000

typedef struct edgenode {
    int y;
    struct edgenode *next;
} edgenode;

typedef struct {
    edgenode *edges[MAXV + 1];
    int degree[MAXV + 1];
    int nvertices;
} graph;

typedef struct {
    int color;  // Used for marking the state of the vertex (0 = white, 1 = gray, 2 = black)
    int d;      // Discovery time
    int f;      // Finish time
    int parent; // Parent vertex in DFS tree
    int low;    // Lowest discovery time reachable from vertex
    bool articulation; // Whether the vertex is an articulation point
} dfs_vertex;

void initialize_graph(graph *g) {
    g->nvertices = 0;
    for (int i = 1; i <= MAXV; i++) {
        g->edges[i] = NULL;
        g->degree[i] = 0;
    }
}

void insert_edge(graph *g, int x, int y) {
    edgenode *p = malloc(sizeof(edgenode));
    p->y = y;
    p->next = g->edges[x];
    g->edges[x] = p;
    g->degree[x]++;

    edgenode *q = malloc(sizeof(edgenode));
    q->y = x;
    q->next = g->edges[y];
    g->edges[y] = q;
    g->degree[y]++;
}

// Global variables for DFS state
dfs_vertex vertices[MAXV + 1];
int time_counter;

// Approach for dfs_articulation function:
// This function should explore the graph using Depth First Search (DFS) to identify articulation points.
// - An articulation point is a vertex that, when removed, increases the number of connected components in the graph.
// - The function should update the discovery time, finish time, and low values for each vertex.
// - The low value should keep track of the earliest discovered vertex reachable from a given vertex by a back edge.
// - The function must also check the articulation condition using DFS traversal to find articulation points.
//
// Expected output:
// - Update the `articulation` field for each vertex and print the articulation points after traversal.
void dfs_articulation(graph *g, int u) {
    vertices[u].color = 1;
    vertices[u].d = ++time_counter;
    edgenode * temp = g->edges[u];
    while (temp != NULL)
    {
        if(vertices[temp->y].color == 0){
            vertices[temp->y].parent = u;
            dfs_articulation(g,temp->y);
        }
    
        temp = temp->next;
    }
    vertices[u].color = 2;
    time_counter++;
    vertices[u].f = time_counter;
    // Task 4
}

// Approach for find_articulation_points function:
// This function should find and print all articulation points in the graph.
// - Initialize all vertices to be unvisited and call `dfs_articulation` on each unvisited vertex.
// - The function should print out the articulation points and a table with vertex information including discovery time, low value, and whether the vertex is an articulation point.
//
// Expected output:
// - The function should print the articulation points and a table displaying the discovery time, low values, and whether each vertex is an articulation point.
void find_articulation_points(graph *g) {
    // Task 5
    for (int i = 1; i <=g->nvertices; i++)
    {
        vertices[i].color = 0;
        vertices[i].low = 10000;
        vertices[i].parent = -1;
    }
    
    
    // Print the table with columns: vertex, d (discovery time), low, articulation (yes/no)
    printf("Vertex | d  | low | Articulation\n");
    printf("----------------------------------\n");
    for (int i = 1; i <= g->nvertices; i++) {
        printf("%6d | %2d | %4d | %s\n", i, vertices[i].d, vertices[i].low, vertices[i].articulation ? "Yes" : "No");
    }
}

int main() {
    graph g;
    initialize_graph(&g);

    g.nvertices = 6;
    insert_edge(&g, 1, 2);
    insert_edge(&g, 1, 4);
    insert_edge(&g, 3, 4);
    insert_edge(&g, 2, 3);
    insert_edge(&g, 5, 3);
    insert_edge(&g, 3, 6);
    insert_edge(&g, 5, 6);

    find_articulation_points(&g);
    return 0;
}
