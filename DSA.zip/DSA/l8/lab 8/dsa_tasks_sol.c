/*
    Name:        <full name>
    Roll No:    <roll number>
    Course:        CS2130 DSA Lab
    Semester:    2024 Jan-Apr
    Lab:        Week 9
    Tasks:        Infix to Postfix Conversion using Shunting Yard Algorithm
    Aim:         Convert an infix expression to postfix expression
*/

#include <stdio.h>
#include <limits.h>
#include <string.h>
#include<stdlib.h>
#include "stack.h"
#include "token.h"


/* Function to return the precedence of an operator */
int precedence(char op) {
    switch (op) {
        case '+':
        case '-':
            return 1;
        case '*':
        case '/':
            return 2;
        case '~': // Unary negation has higher precedence
            return 3;
        default:
            return 0; // For parentheses and other characters
    }
}


/* Task 1. Evaluate a given fully parenthesised infix expression
*/
int infix_eval(char *str) {
/*
    Input:     A fully parenthesised infix expression
    Output: The result of evaluating the expression
    Steps:
        1.    Tokenise str to get a token array (say ta)
        2.    Declare and initialise an operand stack (say valStack) of required size
            (num of tokens in ta is one way to estimate the size)
        3.    Declare and initialise an operator stack (say opStack) of required size
            (num of tokens in ta is one way to estimate the size)
            (int stack can also hold characters)
        3.    Linearly process ta till you hit a token of type EoS
            a)     If the current token is an operand, push the value to valStack
            b)     If the current token is a parOpen, push the paranthesis to opStack
            c)     If the current token is an operator  push the operator (char) to opStack
            d)     If the current token is a parClose then do the following computation
                - pop opStack and store the result in a character op
                -    If op is '('
                    -    Skip over it
                -    Else If op is the unary negation ~
                    -    pop valStack once,
                        (break the token scan if you get INT_MIN as value)
                    -    negate the popped value, and
                    -    push the result back to valStack
                -    Else If op is a binary operator
                    -    pop valStack twice to get val2 and val1 (in that order)
                        (break the token scan if you get INT_MIN as either value)
                    -    compute the result = val1 operator val2 using a switch case
                        on the operator, and
                    -    push the result back to valStack
                -    pop opStack once more and confirm that it is '('
                    Otherwise break
        4.    If the current token is EoS, the final result can be popped from
            the valStack.
            Otherwise the token processing was not complete. In this case,
            free the stacks and return INT_MIN
        5.    Now check that the valStack and opStack are empty to make sure that
            the expression was valid.
            Otherwise the token processing was not complete. In this case,
            free the stacks and return INT_MIN

    Error repsonse:     Print the following error messages to stderr and return INT_MIN
        1. Tokenise error:  "Error: Could not tokenise <str>. Returning <INT_MIN>.\n"
        2. Evalution error: "Error in infix_eval: Invalid infix expression\n"
*/
    Token*    ta = tokenise(str);
    if(ta == NULL){
        fprintf(stderr, "Error: Could not tokenise %s. Returning %d.\n", str, INT_MIN);
        return INT_MIN;
    }

    int numTokens = 0;
    while(ta[numTokens++].type != EoS);

    iStack valStack;
    init_is(&valStack, numTokens);

    iStack opStack;        // Integer stack can also hold characters
    init_is(&opStack, numTokens);
    
    while (ta->type != EoS)
    {
        if (ta->type == operand){
            push_is(&valStack,ta->value);
        }
        else if (ta->type == parOpen){
            push_is(&opStack,ta->op);
        }
        else if (ta->type == operator){
            push_is(&opStack,ta->op);
        }
        else if (ta->type == parClose){
            char op = pop_is(&opStack);
            if (op == '('){
                continue;     
            }
            else if (op == '~'){
                int num = pop_is(&valStack);
                if (num == INT_MIN){
                    break;
                }
                num = -num;
                push_is(&valStack,num);
            }
            else if (op == '+' || op == '-' || op == '*' || op == '/'){
                int num1 = pop_is(&valStack);
                int num2 = pop_is(&valStack);
                if ( num1 == INT_MIN || num2 == INT_MIN){
                    break;
                }
                int result;
                switch (op){
                case '+':
                      result = num1 + num2;
                      break;
                case '-':
                      result = num2 - num1;
                      break;
                case '*':
                      result = num1 * num2;
                      break;
                case '/':
                      result = num2/num1;
                      break;
                default:
                    break;
                }
                push_is(&valStack,result);
            }
            op = pop_is(&opStack);
            if ( op != '('){
                break;
            }         
        }
        ta++;
    }
    int result;
    if (ta->type == EoS){
        result = pop_is(&valStack);
    }

    if (!isempty_is(&valStack) || !isempty_is(&opStack)){
        free_is(&valStack);
        free_is(&opStack);
        return INT_MIN;
    }
    // Task 1. Solution
    free_is(&valStack);
    free_is(&opStack);

    return result; // You may want to edit this
}



/* Task 2. Convert a given fully parenthesised infix expression to a postfix expression
*/

char* infix_to_postfix(char *str) {
    /*
        Input:  A fully parenthesised infix expression
        Output: The postfix expression as a string
        Steps:
            1. Tokenise str to get a token array (say ta)
            2. Declare and initialise an operator stack (say opStack)
            3. Declare a string to store the postfix expression
            4. Linearly process ta till you hit a token of type EoS
                a) If the current token is an operand, append it to the postfix string
                b) If the current token is a parOpen, push '(' to opStack
                c) If the current token is an operator:
                    - Pop from opStack and append to postfix string while the top of the stack has higher or equal precedence
                    - Push the current operator to opStack
                d) If the current token is a parClose, pop from opStack and append to postfix string until '(' is encountered
            5. When the current token is EoS, pop all remaining operators from opStack and append to postfix string
        Error response: Print the following error messages to stderr and return NULL
            1. Tokenise error:  "Error: Could not tokenise <str>. Returning NULL.\n"
            2. Evaluation error: "Error; Invalid infix expression\n"
    */
    // Tokenise the input string
    Token* ta = tokenise(str);
    if (ta == NULL) {
        fprintf(stderr, "Error: Could not tokenise %s. Returning NULL.\n", str);
        return NULL;
    }

    // Initialize operator stack
    iStack opStack;
    init_is(&opStack, 100); // Assuming a maximum capacity of 100 for the stack

    // Initialize postfix string
    char* postfix = (char*)malloc(1000 * sizeof(char)); // Assuming a maximum length of 1000 for the postfix expression
    int postfix_index = 0;
    
  //Task 2: Solution
    while(ta->type != EoS){
        if (ta->type == operand){
            postfix_index += sprintf(postfix+postfix_index, "%d ", ta->value);
        }
        if (ta->type == parOpen){
            push_is(&opStack,ta->op);
        }
        if (ta->type == operator){
            push_is(&opStack,ta->op);      
        }
        if (ta->type == parClose){
             char op = pop_is(&opStack);
             postfix_index += sprintf(postfix+postfix_index, "%c ", op);
             pop_is(&opStack);
        }
        ta++;
    }
    if (ta->type == EoS){
        while (!isempty_is(&opStack))
        {
            char op = pop_is(&opStack);
            postfix_index += sprintf(postfix+postfix_index, "%c ", op);
        }   
    }
    else{
        fprintf(stderr,"Error : invalid infix expression\n");
        return NULL;
    }
    free_is(&opStack);
    postfix[strlen(postfix)] = '\0';
    return postfix;
}

/* Task 3. Evaluate a given postfix expression
*/

int postfix_eval(char *str) {
/*
	Input: 	A postfix expression
	Output: The result of evaluating the expression
	Steps:
		1.	Tokenise str to get a token array (say ta)
		2.	Declare and initialise an operand stack (say valStack) of required size
			(num of operand tokens in ta is one way to estimate the size)
		3.	Linearly process ta till you hit a token of type EoS
			a) 	If the current token is an operand, push the value to valStack
			b) 	If the current token is the unary negation
				-	pop valStack, 
				-	negate the popped value, and 
				-	push the result back to valStack
			b) 	If the current token is a binary operator
				-	pop valStack twice to get val2 and val1 (in that order)
				-	compute the result = val1 operator val2 using a switch case
					on the operator, and
				-	push the result back to valStack
		4.	When the current token is EoS, the final result can be popped from
			the valStack.
	Error repsonse:	 Print the following error messages to stderr and return INT_MIN
		1. Tokenise error:  "Error: Could not tokenise <str>. Returning <INT_MIN>.\n"
		2. Evalution error: "Error; Invalid postfix expression\n"
*/
	Token*    ta = tokenise(str);
    if(ta == NULL){
        fprintf(stderr, "Error: Could not tokenise %s. Returning %d.\n", str, INT_MIN);
        return INT_MIN;
    }

    int numTokens = 0;
    while(ta[numTokens++].type != EoS);

    iStack valStack;
    init_is(&valStack, numTokens);

    iStack opStack;        // Integer stack can also hold characters
    init_is(&opStack, numTokens);
    
    while (ta->type != EoS)
    {
        if (ta->type == operand){
            push_is(&valStack,ta->value);
        }
        else if (ta->type == parOpen){
            push_is(&opStack,ta->op);
        }
        else if (ta->type == operator){
            push_is(&opStack,ta->op);
        }
        else if (ta->type == parClose){
            char op = pop_is(&opStack);
            if (op == '('){
                continue;     
            }
            else if (op == '~'){
                int num = pop_is(&valStack);
                if (num == INT_MIN){
                    break;
                }
                num = -num;
                push_is(&valStack,num);
            }
            else if (op == '+' || op == '-' || op == '*' || op == '/'){
                int num1 = pop_is(&valStack);
                int num2 = pop_is(&valStack);
                if ( num1 == INT_MIN || num2 == INT_MIN){
                    break;
                }
                int result;
                switch (op){
                case '+':
                      result = num1 + num2;
                      break;
                case '-':
                      result = num2 - num1;
                      break;
                case '*':
                      result = num1 * num2;
                      break;
                case '/':
                      result = num2/num1;
                      break;
                default:
                    break;
                }
                push_is(&valStack,result);
            }
            op = pop_is(&opStack);
            if ( op != '('){
                break;
            }
            
        }
        ta++;
    }
    int result;
    if (ta->type == EoS){
        result = pop_is(&valStack);
    }

    if (!isempty_is(&valStack) || !isempty_is(&opStack)){
        free_is(&valStack);
        free_is(&opStack);
        return INT_MIN;
    }
    // Task 1. Solution
    free_is(&valStack);
    free_is(&opStack);

    return result; // You may want to edit this
}



/* Task 4. Generate an expression tree from a given postfix expression */
eTree* postfix_to_etree(char *str) {
/*
    Input:     A postfix expression
    Output: Pointer to the root of the equivalent expression tree.
    Steps:
        1.    Tokenise str to get a token array (say ta)
        2.    Declare and initialise a Node Stack (say nodeStack)
            (num of operand tokens in ta is one way to estimate the size)
        3.    Linearly process ta till you hit a token of type EoS
            a)     If the current token is an operand
                -    Create a new operand node with
                    -     current token as node token
                    -     NULL as left and NULL as right pointers
                    -    push this node to nodeStack
            b)     If the current token is the unary negation
                -    pop nodeStack once to get a single node t,
                    (break the token scan if you get NULL in this pop)
                -    Create a new operator node with
                    ~     current token as the node token
                    -    the popped node  t as its right child
                    -    NULL as its left child
                -    push this new node to nodeStack
            b)     If the current token is a binary operator
                -    pop nodeStack twice to get two nodes n2 and n1 (in that order)
                    (break the token scan if you get NULL in either pop)
                -    Create a new operator node token with
                    ~     current token as the node token
                    -    the popped node  n1 as its left child
                    -    the popped token  n2 as its right child
                -    push this new node to ns
        4.    When the current token is EoS, nodeStack contains only the root node
            of the expression tree
        5.    If either the current token is not EoS or result is INT_MIN or
            the valStack is not empty after the last pop, the expression was
            invalid. Print an error and return INT_MIN.

    Error response:     Print the following error messages to stderr and return NULL
        1. Tokenise error:  "Error: Could not tokenise <str>. Returning <INT_MIN>.\n"
        2. Evaluation error: "Error; Invalid postfix expression\n"
*/

    Token* ta = tokenise(str);
    if(ta == NULL){
        fprintf(stderr, "Error: Could not tokenise %s. Returning %d.\n", str, INT_MIN);
        return NULL;
    }

    int numVals = 0, i = 0;
    while(ta[i].type != EoS){
        if(ta[i].type == operand){
            numVals++;
        }
        i++;
    }
        
    pStack nodeStack;
    init_ps(&nodeStack, numVals);
    
    eTree *node1, *node2;

    // Task 4. Solution

    while(ta->type != EoS){
        if(ta->type == operand){
            eTree* new = create_node(*ta,NULL, NULL);
            push_ps(&nodeStack, new);
        }
        else if (ta->type == operator){

            if (ta->op == '~'){
                node2 = pop_ps(&nodeStack);
                if ( node1 == NULL){
                    return NULL;
                }
                node1 = NULL;
            }
            else {
                node2 = pop_ps(&nodeStack);
                node1 = pop_ps(&nodeStack);
            }
            push_ps(&nodeStack,create_node(*ta,node1,node2));
        }
        ta++;
    }
    node1 = pop_ps(&nodeStack);
    if (!isempty_ps(&nodeStack)){
        node1 = NULL;
    }
    free_ps(&nodeStack);

    return node1;  // You may want to edit this
}




/* Task 5. Evaluate a given expression tree
*/
int etree_eval(eTree *t) {
/*     Input:    The root of an expression tree
    Action: Evaluate the expression tree recursively and return the answer
*/
    if (t == NULL) {
        fprintf(stderr, "Error in etree_eval: Trying to evaluate an empty tree\n");
        return INT_MIN;
    }

    // Task 5. Solution
}

/* Task 6. Genrate a fully parenthesised infix expression from a given expression tree
*/

void etree_to_infix(eTree *t) {
/*     Input:    The root of an expression tree
    Action: Print the fully parenthesised infix expression of this tree
            Single operands should not be in parenthesis
*/
    if (t == NULL)
        return;
        
    // Task 6 . Solution

}
int main(){
Token *ta;

	// Testing postfix_eval()
	printf("\nTesting Tasks 1 to 6.\n");
	printf("=======================\n");

	int nTests = 7;
	char infix[][100] = {
		"(2+31)",					// 33	
		"(2+(~31))", 				//-29
		"(10/(~(2+3)))", 			// ~2
		"((2+(3*1))-9)", 			// -4
		"(((2-3)+4)*(5+(6*7)))",	// 141
		"(((1+2-3)+4)*(5+(6*7)))",	// Invalid
		"(((2-3))+4)*(5+(6*7)))",	// Invalid
	};

	int result, result2;
	eTree *root;
	for(int i = 0; i < nTests; i++) {
		char* s = infix[i];
		// Task 1 Test
		printf("\n%d. Processing \"%s\"\n", i, s);
		printf("-----------------------------\n");
		result = infix_eval(s);
		printf("Task 1: Evaluate infix expression: Result = %d\n", result);
        if (result == INT_MIN)
        {
            continue;
        }
        
        // Task 2: Infix to Postfix Conversion
        char* postfix = infix_to_postfix(s);
        if (postfix != NULL) 
        {
            printf("Task 2: Infix to Postfix: %s\n", postfix);
        } else 
        {
            printf("Task 2: Infix to Postfix: Error\n");
            continue;
        }
	    // Task 3 Test
		result2 = postfix_eval(s);
		printf("Task 3: Evaluate postfix expression: Result = %d\n", result2);

		root = postfix_to_etree(postfix);
		if(root == NULL){
			printf("Task 4: Invalid postfix expression\n");
            continue;

		}
		else {
			printf("Task 4: Expression Tree\n", 
				root->token.value, root->token.op);
			print_etree(root);
		}

		result = etree_eval(root);
		printf("Task 5: Evaluate expression tree: Result =%d\n", result );


        printf("Task 6: Fully parenthesised infix expression: ");
		etree_to_infix(root);
		printf("\n");
    }
}
