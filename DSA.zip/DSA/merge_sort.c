#include<stdio.h>

void merge(int *arr,int start,int mid,int end){
     int n1 = mid - start +1;
     int n2 = end - mid;
     int l[n1];
     int r[n2];
     for (int i=0; i<n1; i++){
        l[i]=arr[start+i];
     }
     for (int i=0; i<n2; i++){
        r[i]=arr[mid+1+i];
     }
     int i = 0;
     int j = 0;
     int k = start;
     while (i < n1 && j < n2) {
         if (l[i] <= r[j]) {
             arr[k] = l[i];
             i++;
         }
         else {
             arr[k] = r[j];
             j++;
         }
         k++;
     }
 
     // Copy the remaining elements of leftArr[], if any
     while (i < n1) {
         arr[k] = l[i];
         i++;
         k++;
     }
 
     // Copy the remaining elements of rightArr[], if any
     while (j < n2) {
         arr[k] = r[j];
         j++;
         k++;
     }
}

void mergesort(int *arr,int start,int end){
     if (start<end){
        int mid = (start+end)/2;
        mergesort(arr,start,mid);
        mergesort(arr,mid+1,end);
        merge(arr,start,mid,end);
     }
}

void printarr(int* arr,int start, int end){
     for(int i=start; i<end; i++){
         printf("%d ",arr[i]);
     }
     printf("\n");
}

int main(){
    int A[] = {2,4,6,7,1,2,3,5};
    int n = sizeof(A)/sizeof(A[0]);
    printarr(A,0,n);
    mergesort(A,0,n-1);
    printarr(A,0,n);    
}